module org.example.g_ressourcehumaine {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires java.sql;

    opens org.example.g_ressourcehumaine to javafx.fxml;
    opens org.example.g_ressourcehumaine.controllers to javafx.fxml; // ✅ Ajoutez cette ligne
    opens org.example.g_ressourcehumaine.models to javafx.base;


    exports org.example.g_ressourcehumaine;
}
