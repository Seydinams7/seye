package org.example.g_ressourcehumaine.models;

import java.util.Date;

public class Tache {
    private int id;
    private String titre;
    private String description;
    private Date dateLimite;
    private String etat;
    private int employe_id;

    public Tache(int id, String titre, String description, Date dateLimite, String etat, int employe_id) {
        this.id = id;
        this.titre = titre;
        this.description = description;
        this.dateLimite = dateLimite;
        this.etat = etat;
        this.employe_id = employe_id;
    }

    public Tache(int id, String titre, String description, String etat, int employe_id) {
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Date getDateLimite() { return dateLimite; }
    public void setDateLimite(Date dateLimite) { this.dateLimite = dateLimite; }

    public String getEtat() { return etat; }
    public void setEtat(String etat) { this.etat = etat; }

    public int getEmploye_id() { return employe_id; }
    public void setEmploye_id(int employe_id) { this.employe_id = employe_id; }
}
