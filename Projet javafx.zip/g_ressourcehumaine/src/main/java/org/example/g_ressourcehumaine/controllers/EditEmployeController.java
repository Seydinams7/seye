package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.Employe;
import org.example.g_ressourcehumaine.models.Tache;
import org.example.g_ressourcehumaine.controllers.ManagerController;

import java.sql.*;
import java.time.LocalDate;
import java.time.ZoneId;

public class EditEmployeController {


    @FXML private TextField nomField;
    @FXML private TextField posteField;
    @FXML private DatePicker datedembauchePicker;
    @FXML private TextField salaireField;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion_ressource_humaine";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private Employe employeToEdit;
    private int department_id;
    private int employe_id;


    // Méthode pour définir les données de la tâche à modifier
    public void setEmployeData(Employe employe) {
        this.employeToEdit = employe;

        // Initialiser department_id et employe_id à partir de l'employé
        this.department_id = employe.getDepartement_id();  // Assurez-vous que la méthode getDepartement_id() existe
        this.employe_id = employe.getId();  // Assurez-vous que la méthode getId() existe

        // Remplir les champs avec les données de l'employé
        nomField.setText(employe.getNom_complet());
        posteField.setText(employe.getPoste());
        datedembauchePicker.setValue(employe.getDate_embauche().toLocalDate());
        salaireField.setText(String.valueOf(employe.getSalaire()));
    }


    public void handleSave(ActionEvent event) {
        String nom = nomField.getText();
        String poste = posteField.getText();
        LocalDate localDate = datedembauchePicker.getValue();  // LocalDate de JavaFX

        // Conversion de LocalDate en java.sql.Date
        java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);

        double salaire = Double.parseDouble(salaireField.getText());

        // Vérification des champs
        if (nom.isEmpty() || poste.isEmpty() || sqlDate == null || salaireField.getText().isEmpty()) {
            showAlert("Erreur", "Tous les champs doivent être remplis.", Alert.AlertType.ERROR);
            return;
        }

        try {
            String sql = "UPDATE employes SET nom_complet = ?, poste = ?, date_embauche = ?, salaire = ?, departement_id = ? WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, nom);
                stmt.setString(2, poste);
                stmt.setDate(3, sqlDate);  // Utilisez sqlDate ici
                stmt.setDouble(4, salaire);
                stmt.setInt(5, department_id);  // Assurez-vous que departmentId est correct
                stmt.setInt(6, employe_id);  // Assurez-vous que employeeId est correct


                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    showAlert("Succès", "L'employé a été modifié avec succès.", Alert.AlertType.INFORMATION);

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la modification de l'employé.", Alert.AlertType.ERROR);
        }
    }

    // Méthode pour sauvegarder les modifications dans la base de données
    private void updateEmployeInDatabase(Employe employe) {
        String updateQuery = "UPDATE employes SET nom_complet = ?, poste = ?, date_embauche = ?, salaire = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
            stmt.setString(1, employe.getNom_complet());
            stmt.setString(2, employe.getPoste());

            // Convertir java.util.Date en java.sql.Date
            java.sql.Date sqlDate = new java.sql.Date(employe.getDate_embauche().getTime());
            stmt.setDate(3, sqlDate);

            stmt.setDouble(4, employe.getSalaire());
            stmt.setInt(5, employe.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la sauvegarde des modifications.", Alert.AlertType.ERROR);
        }
    }

    // Afficher une alerte
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) nomField.getScene().getWindow();
        stage.close();
    }
}
