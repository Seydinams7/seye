package org.example.g_ressourcehumaine.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.Employe;
import org.example.g_ressourcehumaine.controllers.ModifyEmployeeController;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import org.example.g_ressourcehumaine.models.Employe;


public class ManageEmployeesController implements Initializable {

    @FXML
    private TextField nameField;
    @FXML
    private TextField positionField;
    @FXML
    private TextField salaryField;
    @FXML
    private TextField dateField;

    private Employe employee;

    @FXML
    private TableView<Employe> tableViewEmployes;
    @FXML
    private TableColumn<Employe, Integer> columnId;
    @FXML
    private TableColumn<Employe, String> columnName;
    @FXML
    private TableColumn<Employe, String> columnPosition;
    @FXML
    private TableColumn<Employe, Double> columnSalary;
    @FXML
    private TableColumn<Employe, Date> columnDate;
    @FXML
    private Button btnAddEmployee;
    @FXML
    private Button btnAdminhome;
    @FXML
    private Button btnModify;
    @FXML
    private Button btnDeleteEmployee;
    @FXML
    private Button btnRefresh;

    private ObservableList<Employe> employesList = FXCollections.observableArrayList();




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialisation des colonnes de la TableView
        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnName.setCellValueFactory(new PropertyValueFactory<>("nom_complet"));
        columnPosition.setCellValueFactory(new PropertyValueFactory<>("poste"));
        columnSalary.setCellValueFactory(new PropertyValueFactory<>("salaire"));
        columnDate.setCellValueFactory(new PropertyValueFactory<>("date_embauche"));

        // Charger les employés
        loadEmployes();
    }

    // Cette méthode permet de recevoir l'employé sélectionné

    // Méthode pour charger les employés depuis la base de données
    private void loadEmployes() {
        employesList.clear();
        String query = "SELECT * FROM employes";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Employe employee = new Employe(
                        rs.getInt("id"),
                        rs.getString("nom_complet"),
                        rs.getString("poste"),
                        rs.getDouble("salaire"),
                        rs.getDate("date_embauche"),
                        rs.getInt("departement_id")
                );
                employesList.add(employee);
            }
            tableViewEmployes.setItems(employesList);

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger les employés.", Alert.AlertType.ERROR);
        }
    }

    // Méthode pour afficher une alerte
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Navigation vers une autre vue
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    // Ajouter un employé
    @FXML

    public void handleAdminhome(ActionEvent event){
        navigateTo("admin.fxml",btnAdminhome);
    }
    @FXML
    public void handleAddEmployee(ActionEvent event) {
        navigateTo("AddEmployee.fxml", btnAddEmployee);
    }

    // Supprimer un employé sélectionné
    @FXML
    public void handleDeleteEmployee(ActionEvent event) {
        Employe selectedEmploye = tableViewEmployes.getSelectionModel().getSelectedItem();
        if (selectedEmploye == null) {
            showAlert("Attention", "Veuillez sélectionner un employé à supprimer.", Alert.AlertType.WARNING);
            return;
        }

        String query = "DELETE FROM employes WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedEmploye.getId());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                showAlert("Succès", "Employé supprimé avec succès.", Alert.AlertType.INFORMATION);
                loadEmployes(); // Rafraîchir la table
            } else {
                showAlert("Erreur", "La suppression a échoué.", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de supprimer l'employé.", Alert.AlertType.ERROR);
        }
    }

    // Rafraîchir la liste des employés
    @FXML
    public void handleModifyEmployee(ActionEvent event) {
        Employe selectedEmployee = tableViewEmployes.getSelectionModel().getSelectedItem();

        // Vérifier si un employé a été sélectionné
        if (selectedEmployee == null) {
            // Afficher un message d'erreur si aucun employé n'est sélectionné
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucun employé sélectionné");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez sélectionner un employé à modifier.");
            alert.showAndWait();
            return;
        }

        // Créer un formulaire de modification (nouvelle fenêtre ou dialog)
        try {
            // Charger le fichier FXML du formulaire de modification
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/modifyEmployeeForm.fxml"));
            Parent root = loader.load();

            // Passer l'employé sélectionné au contrôleur de la fenêtre de modification
            ModifyEmployeeController modifyController = loader.getController();
            modifyController.setEmployee(selectedEmployee); // Passer l'employé à modifier

            // Afficher la nouvelle fenêtre dans un Stage
            Stage stage = new Stage();
            stage.setTitle("Modifier un employé");
            stage.setScene(new Scene(root));
            stage.showAndWait(); // Attendre que l'utilisateur ferme la fenêtre
        } catch (IOException e) {
            e.printStackTrace();
            // Gérer les erreurs de chargement de la fenêtre de modification
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur lors de l'ouverture du formulaire de modification");
            alert.setContentText("Impossible de charger le formulaire de modification.");
            alert.showAndWait();

        }
    }


    public void handleRefreshEmployee(ActionEvent event) {
        loadEmployes();
    }
}
