package org.example.g_ressourcehumaine.controllers;



import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class DashboardController {

    @FXML
    public void goToEmployes() throws IOException {
        changeScene("views/Employes.fxml");
    }

    @FXML
    public void goToDepartements() throws IOException {
        changeScene("views/Departements.fxml");
    }

    @FXML
    public void goToTaches() throws IOException {
        changeScene("views/Taches.fxml");
    }

    private void changeScene(String fxmlFile) throws IOException {
        Stage stage = (Stage) new Stage();
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        stage.setScene(new Scene(root));
        stage.show();
    }
}
