package org.example.g_ressourcehumaine.controllers;



import org.example.g_ressourcehumaine.database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.g_ressourcehumaine.models.Employe;
import org.example.g_ressourcehumaine.utils.SessionManager;

import java.sql.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class EmployesController {
    @FXML private TableView<Employe> tableEmployes;
    @FXML private TextField nomField, posteField, salaireField, dateField;
    @FXML private ComboBox<String> departementCombo;

    private ObservableList<Employe> employesList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        chargerEmployes();
    }

    private void chargerEmployes() {
        employesList.clear();
        try (Connection conn = DatabaseConnection.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employes");
            while (rs.next()) {
                employesList.add(new Employe(rs.getInt("id"), rs.getString("nom_complet"),
                        rs.getString("poste"), rs.getDouble("salaire"), rs.getDate("date_embauche"), rs.getInt("departement_id")));
            }
            tableEmployes.setItems(employesList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @FXML
    private void supprimerEmploye() {
        Employe selectedEmploye = tableEmployes.getSelectionModel().getSelectedItem();
        if (selectedEmploye == null) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM employes WHERE id = ?");
            stmt.setInt(1, selectedEmploye.getId());
            stmt.executeUpdate();
            chargerEmployes();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void afficherAlerte(String titre, String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void ajouterEmploye() {
        if (!SessionManager.estAdmin() && !SessionManager.estManager()) {
            afficherAlerte("Accès refusé", "Vous n'avez pas la permission d'ajouter un employé.");
            return;
        }

        String nom = nomField.getText();
        String poste = posteField.getText();
        double salaire = Double.parseDouble(salaireField.getText());
        Date date = Date.valueOf(dateField.getText());

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO employes (nom_complet, poste, salaire, date_embauche) VALUES (?, ?, ?, ?)");
            stmt.setString(1, nom);
            stmt.setString(2, poste);
            stmt.setDouble(3, salaire);
            stmt.setDate(4, date);
            stmt.executeUpdate();
            chargerEmployes();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



}
