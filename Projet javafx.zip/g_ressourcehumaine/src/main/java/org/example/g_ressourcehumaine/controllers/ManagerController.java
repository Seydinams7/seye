package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.Departement;
import org.example.g_ressourcehumaine.models.Employe;
import org.example.g_ressourcehumaine.models.Tache;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class ManagerController {

    @FXML private TableView<Tache> tableTaches;
    @FXML private TableColumn<Tache, Integer> tacheidColumn;
    @FXML private TableColumn<Tache, String> titreColumn;
    @FXML private TableColumn<Tache, String> descriptionColumn;
    @FXML private TableColumn<Tache, String> etatColumn;
    @FXML private TableColumn<Tache, LocalDate> deadlineColumn;

    @FXML private TableView<Employe> tableEmployes;
    @FXML private TableColumn<Employe, Integer> colEmployeId;
    @FXML private TableColumn<Employe, String> colEmployeNom;
    @FXML private TableColumn<Employe, String> colEmployePoste;
    @FXML private TableColumn<Employe, String> colEmployeDateEmbauche;
    @FXML private TableColumn<Employe, Double> colEmployeSalaire;

    @FXML private TextField titreField;
    @FXML private TextField descriptionField;
    @FXML private TextField etatField;
    @FXML private DatePicker deadlineField;
    @FXML private ComboBox<Employe> employeComboBox;


    @FXML private TextField nomField;
    @FXML private TextField posteField;
    @FXML private TextField salaireField;
    @FXML private DatePicker datedembaucheField;




    private ObservableList<Tache> tachesData = FXCollections.observableArrayList();
    private ObservableList<Employe> employesData = FXCollections.observableArrayList();

    private Tache tache; // Déclare la variable

    private Employe employe;



    private Connection connection;
    private int managerId;
    private int departementId;

    public void initialize() throws SQLException {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        loadEmployes();
        loadTaches();
    }
    public void setTaskData(Tache tache) {
        if (tache == null) {
            System.out.println("Aucune tâche reçue !");
            return;
        }

        this.tache = tache;

        // Remplissage des champs
        titreField.setText(tache.getTitre());
        descriptionField.setText(tache.getDescription());
        etatField.setText(tache.getEtat());


    }
    public void setEmployeData(Employe employe) {
        if (employe == null) {
            System.out.println("Aucun employe reçu !");
            return;
        }

        this.employe = employe;

        // Remplissage des champs
        nomField.setText(employe.getNom_complet());
        posteField.setText(employe.getPoste());
        salaireField.setText(String.valueOf(employe.getSalaire()));


    }


    public void setManagerData(int managerId, int departementId) {
        this.managerId = managerId;
        this.departementId = departementId;
        try {
            loadEmployes();
            loadTaches();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadEmployes() throws SQLException {
        employesData.clear();
        String query = "SELECT * FROM employes WHERE departement_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, departementId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Employe employe = new Employe(
                        rs.getInt("id"),
                        rs.getString("nom_complet"),
                        rs.getString("poste"),
                        rs.getDouble("salaire"),
                        rs.getDate("date_embauche"),
                        rs.getInt("departement_id")
                );
                employesData.add(employe);
            }
        }
        // Associer les colonnes du TableView des employés
        colEmployeId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colEmployeNom.setCellValueFactory(new PropertyValueFactory<>("nom_complet"));
        colEmployePoste.setCellValueFactory(new PropertyValueFactory<>("poste"));
        colEmployeDateEmbauche.setCellValueFactory(new PropertyValueFactory<>("date_embauche"));
        colEmployeSalaire.setCellValueFactory(new PropertyValueFactory<>("salaire"));
         // Charge les employés pour ce manager

        tableEmployes.setItems(employesData);
        employeComboBox.setItems(employesData);
        employeComboBox.setCellFactory(param -> new ListCell<Employe>() {
            @Override
            protected void updateItem(Employe item, boolean empty) {
                super.updateItem(item, empty);
                setText((item == null || empty) ? "" : item.getNom_complet());
            }
        });
    }

    private void loadTaches() throws SQLException {
        tachesData.clear();
        String query = "SELECT * FROM taches WHERE employe_id IN (SELECT id FROM employes WHERE departement_id = ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, departementId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Tache tache = new Tache(
                        rs.getInt("id"),
                        rs.getString("titre"),
                        rs.getString("description"),
                        rs.getDate("date_limite"),
                        rs.getString("etat"),
                        rs.getInt("employe_id")
                );
                tachesData.add(tache);
            }
        }

        tacheidColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titreColumn.setCellValueFactory(new PropertyValueFactory<>("titre"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        etatColumn.setCellValueFactory(new PropertyValueFactory<>("etat"));
        deadlineColumn.setCellValueFactory(new PropertyValueFactory<>("dateLimite"));

        tableTaches.setItems(tachesData);
    }

    @FXML
    private void handleEditTask(ActionEvent event) {
        Tache selectedTache = tableTaches.getSelectionModel().getSelectedItem();
        if (selectedTache == null) {
            showAlert("Sélection requise", "Veuillez sélectionner une tâche à modifier.",Alert.AlertType.ERROR);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/editTask.fxml"));
            Parent root = loader.load();
            EditTaskController editTaskController = loader.getController();
            editTaskController.setTaskData(selectedTache);

            Stage stage = new Stage();
            stage.setTitle("Modifier la tâche");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de l'ouverture de la fenêtre de modification.", Alert.AlertType.ERROR);
        }
    }
    @FXML
    private void handleAddTask(ActionEvent event) {
        String titre = titreField.getText();
        String description = descriptionField.getText();
        String etat = etatField.getText(); // Le TextField pour l'état de la tâche
        LocalDate dateLimite = deadlineField.getValue(); // Utilise "date_limite" dans la table

        // Vérification des champs
        if (titre.isEmpty() || description.isEmpty() || etat.isEmpty() || dateLimite == null) {
            showAlert("Erreur","Tous les champs doivent être remplis.", Alert.AlertType.ERROR);
            return;
        }

        try {
            String sql = "INSERT INTO taches (titre, description, date_limite, etat, employe_id) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                // Récupérer l'ID de l'employé sélectionné dans le ComboBox
                Employe selectedEmploye = employeComboBox.getValue();
                int employe_id = selectedEmploye.getId();

                stmt.setString(1, titre);
                stmt.setString(2, description);
                stmt.setDate(3, Date.valueOf(dateLimite)); // Convertir LocalDate en Date SQL
                stmt.setString(4, etat);
                stmt.setInt(5, employe_id);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    showAlert("Succes","Tâche ajoutée avec succès.",Alert.AlertType.INFORMATION);
                    loadTaches(); // Recharger les tâches dans le tableau
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur","Erreur lors de l'ajout de la tâche.",Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteTask(ActionEvent event) {
        Tache selectedTask = tableTaches.getSelectionModel().getSelectedItem();
        if (selectedTask == null) {
            showAlert("Erreur", "Veuillez sélectionner une tâche à supprimer.", Alert.AlertType.ERROR);
            return;
        }

        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION, "Êtes-vous sûr de vouloir supprimer cette tâche ?", ButtonType.YES, ButtonType.NO);
        if (confirmationAlert.showAndWait().orElse(ButtonType.NO) == ButtonType.YES) {
            String deleteQuery = "DELETE FROM taches WHERE id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteQuery)) {
                stmt.setInt(1, selectedTask.getId());
                if (stmt.executeUpdate() > 0) {
                    tableTaches.getItems().remove(selectedTask);
                    showAlert("Succès", "Tâche supprimée avec succès.", Alert.AlertType.INFORMATION);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Erreur", "Impossible de supprimer la tâche.", Alert.AlertType.ERROR);
            }
        }
    }
    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleLogout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/public_view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) tableTaches.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleEditEmploye(ActionEvent event) {
        Employe selectedEmploye = tableEmployes.getSelectionModel().getSelectedItem();
        if (selectedEmploye == null) {
            showAlert("Sélection requise", "Veuillez sélectionner un employe à modifier.",Alert.AlertType.ERROR);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/editEmploye.fxml"));
            Parent root = loader.load();
            EditEmployeController editEmployeController = loader.getController();
            editEmployeController.setEmployeData(selectedEmploye);

            Stage stage = new Stage();
            stage.setTitle("Modifier l'employe");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de l'ouverture de la fenêtre de modification.", Alert.AlertType.ERROR);
        }
    }

    public void handleDeleteEmploye(ActionEvent event) {

        Employe selectedEmploye = tableEmployes.getSelectionModel().getSelectedItem();
        if (selectedEmploye == null) {
            showAlert("Erreur", "Veuillez sélectionner un employe à supprimer.", Alert.AlertType.ERROR);
            return;
        }

        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION, "Êtes-vous sûr de vouloir supprimer cet employe ?", ButtonType.YES, ButtonType.NO);
        if (confirmationAlert.showAndWait().orElse(ButtonType.NO) == ButtonType.YES) {
            String deleteQuery = "DELETE FROM employes WHERE id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteQuery)) {
                stmt.setInt(1, selectedEmploye.getId());
                if (stmt.executeUpdate() > 0) {
                    tableEmployes.getItems().remove(selectedEmploye);
                    showAlert("Succès", "Employe supprimé avec succès.", Alert.AlertType.INFORMATION);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Erreur", "Impossible de supprimer l' employe.", Alert.AlertType.ERROR);
            }
        }
    }

    public void handleAddEmploye(ActionEvent event) {
        String nom_complet = nomField.getText();
        String poste = posteField.getText();
        LocalDate date_embauche = datedembaucheField.getValue();
        double salaire = Double.parseDouble(salaireField.getText());

        // Vérification des champs
        if (nom_complet.isEmpty() || poste.isEmpty() || date_embauche == null || salaireField.getText().isEmpty()) {
            showAlert("Erreur", "Tous les champs doivent être remplis.", Alert.AlertType.ERROR);
            return;
        }

        // Vérifier que le manager a un département
        if (departementId == -1) {
            showAlert("Erreur", "Le manager n'a pas de département assigné.", Alert.AlertType.ERROR);
            return;
        }

        try {
            String sql = "INSERT INTO employes (nom_complet, poste, date_embauche, salaire, departement_id) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, nom_complet);
                stmt.setString(2, poste);
                stmt.setDate(3, Date.valueOf(date_embauche));
                stmt.setDouble(4, salaire);
                stmt.setInt(5, departementId);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    showAlert("Succès", "L'employé a été ajouté avec succès.", Alert.AlertType.INFORMATION);
                    loadEmployes();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de l'ajout de l'employé.", Alert.AlertType.ERROR);
        }
    }
    // Fonction pour obtenir l'ID du manager connecté
    private int getCurrentManagerId() {
        // Ici, tu dois récupérer l'ID du manager connecté depuis l'application (par exemple, à partir de la session ou de la base de données)
        // Pour cet exemple, retournons un ID fictif de manager
        return 1; // Remplace par la logique réelle pour obtenir l'ID du manager connecté
    }

    // Fonction pour obtenir l'ID du département du manager
    private int getManagerDepartementId(int managerId) {
        // Ici, tu récupères le département du manager depuis la base de données
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT id FROM departements WHERE responsable_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, managerId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt("id");  // Récupérer l'ID du département
                    } else {
                        // Si aucun département n'est trouvé, cela signifie qu'il n'y a pas de département assigné pour ce manager
                        System.out.println("Aucun département trouvé pour ce manager.");
                        return -1;  // Retourner -1 pour indiquer un problème
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;  // Si la connexion échoue ou qu'il n'y a pas de résultat
    }

}


