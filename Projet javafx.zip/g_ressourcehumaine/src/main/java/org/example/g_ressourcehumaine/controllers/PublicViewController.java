package org.example.g_ressourcehumaine.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.EmployeeTask;
import org.example.g_ressourcehumaine.utils.DBUtil;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PublicViewController {

    @FXML private TableView<EmployeeTask> tableView;
    @FXML private TableColumn<EmployeeTask, String> colNom;
    @FXML private TableColumn<EmployeeTask, String> colPoste;
    @FXML private TableColumn<EmployeeTask, String> colTache;
    @FXML private TableColumn<EmployeeTask, String> colEtat;
    @FXML private TextField searchField;

    private ObservableList<EmployeeTask> dataList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Associer les colonnes aux attributs
        colNom.setCellValueFactory(cellData -> cellData.getValue().nomProperty());
        colPoste.setCellValueFactory(cellData -> cellData.getValue().posteProperty());
        colTache.setCellValueFactory(cellData -> cellData.getValue().tacheProperty());
        colEtat.setCellValueFactory(cellData -> cellData.getValue().etatProperty());

        loadEmployees();
    }

    private void loadEmployees() {
        dataList.clear();
        String query = "SELECT e.nom_complet, e.poste, t.titre, t.etat " +
                "FROM employes e " +
                "LEFT JOIN taches t ON e.id = t.employe_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                dataList.add(new EmployeeTask(
                        rs.getString("nom_complet"),
                        rs.getString("poste"),
                        rs.getString("titre"),
                        rs.getString("etat")
                ));
            }
            tableView.setItems(dataList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().trim().toLowerCase();
        if (searchText.isEmpty()) {
            tableView.setItems(dataList);
            return;
        }

        ObservableList<EmployeeTask> filteredList = FXCollections.observableArrayList();
        for (EmployeeTask et : dataList) {
            if (et.getNom().toLowerCase().contains(searchText)) {
                filteredList.add(et);
            }
        }
        tableView.setItems(filteredList);
    }

    @FXML
    private void handleLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/Login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) tableView.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
