package org.example.g_ressourcehumaine.utils;

import org.example.g_ressourcehumaine.models.Utilisateur;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBUtil {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion_ressource_humaine"; // Remplace avec ton URL de base de données
    private static final String DB_USERNAME = "root"; // Remplace avec ton nom d'utilisateur DB
    private static final String DB_PASSWORD = ""; // Remplace avec ton mot de passe DB

    // Méthode pour obtenir une connexion à la base de données
    private static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Impossible de se connecter à la base de données.");
        }
    }

    // Méthode pour ajouter un utilisateur dans la base de données


    // Récupérer la liste des noms des départements
    public static List<String> getDepartementNames() {
        List<String> departements = new ArrayList<>();
        String query = "SELECT nom FROM departements";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                departements.add(rs.getString("nom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return departements;
    }

    public static List<String> getRoleNames() {
        List<String> role = new ArrayList<>();
        String query = "SELECT role FROM utilisateurs";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                role.add(rs.getString("role"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return role;
    }

    // Récupérer l'ID d'un département par son nom
    public static int getDepartementIdByName(String nom) {
        String query = "SELECT id FROM departements WHERE nom = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nom);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Retourne -1 si le département n'est pas trouvé
    }

    // Ajouter un employé
    public static boolean addEmployee(String nomComplet, String poste, Date dateEmbauche, double salaire, int departementId) {
        String query = "INSERT INTO employes (nom_complet, poste, date_embauche, salaire, departement_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nomComplet);
            stmt.setString(2, poste);
            stmt.setDate(3, dateEmbauche);
            stmt.setDouble(4, salaire);
            stmt.setInt(5, departementId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean addUser(String nom_utilisateur, String mot_de_passe, String email, String role) {
        String query = "INSERT INTO utilisateurs (nom_utilisateur, mot_de_passe, email, role) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nom_utilisateur);
            stmt.setString(2, mot_de_passe);
            stmt.setString(3, email);
            stmt.setString(4, role);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<String> getEmployeeNames() {
        List<String> employee = new ArrayList<>();
        String query = "SELECT nom_complet FROM employes";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                employee.add(rs.getString("nom_complet"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employee;
    }

    public static int getEmployeeIdByName(String nom_complet) {
        String query = "SELECT id FROM employes WHERE nom_complet = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nom_complet);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Retourne -1 si le département n'est pas trouvé
    }


    public static boolean addTache(String titre, String description, Date dateLimite, String etat, int employe_id) {
        String query = "INSERT INTO taches (titre, description, date_limite, etat, employe_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, titre);
            stmt.setString(2, description);
            stmt.setDate(3, dateLimite);
            stmt.setString(4, etat);
            stmt.setInt(5, employe_id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
