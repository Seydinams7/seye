package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.stage.Stage;
public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button btnLogin;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion_ressource_humaine";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // Variable statique pour l'ID du manager connecté
    private static int currentManagerId;

    @FXML
    public void handleLogin(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Erreur", "Nom d'utilisateur et mot de passe requis.", AlertType.ERROR);
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM utilisateurs WHERE nom_utilisateur = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("id");
                    String storedPassword = rs.getString("mot_de_passe");
                    String role = rs.getString("role");

                    // Vérification du mot de passe haché (SHA-256)
                    if (storedPassword.equals(hashPassword(password))) {
                        showAlert("Succès", "Connexion réussie!", AlertType.INFORMATION);

                        if (role.equals("ADMIN")) {
                            navigateToPage("admin.fxml");
                        } else if (role.equals("MANAGER")) {
                            // Récupérer l'ID du manager et son département
                            currentManagerId = userId;
                            int departmentId = getDepartmentIdForManager(userId);
                            navigateToManagerPage(userId, departmentId);
                        }
                    } else {
                        showAlert("Erreur", "Nom d'utilisateur ou mot de passe incorrect.", AlertType.ERROR);
                    }
                } else {
                    showAlert("Erreur", "Nom d'utilisateur incorrect.", AlertType.ERROR);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur de connexion", "Impossible de se connecter à la base de données.", AlertType.ERROR);
        }
    }

    // Fonction pour récupérer l'ID du département du manager
    private int getDepartmentIdForManager(int managerId) {
        String query = "SELECT id FROM departements WHERE responsable_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, managerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;  // Retourne -1 si aucun département trouvé
    }

    // Naviguer vers la page Manager
    private void navigateToManagerPage(int managerId, int departmentId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/manager.fxml"));
            Parent root = loader.load();

            // Passer les données au contrôleur du Manager
            ManagerController managerController = loader.getController();
            managerController.setManagerData(managerId, departmentId);

            Stage stage = (Stage) btnLogin.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du chargement de la page Manager.", AlertType.ERROR);
        }
    }

    // Hachage du mot de passe avec SHA-256
    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = md.digest(password.getBytes());
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }

    // Afficher une alerte
    private void showAlert(String title, String message, AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Naviguer vers la page Admin
    private void navigateToPage(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) btnLogin.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du chargement de la page.", AlertType.ERROR);
        }
    }

    // Récupérer l'ID du manager connecté (méthode statique)
    public static int getCurrentManagerId() {
        return currentManagerId;
    }
}
