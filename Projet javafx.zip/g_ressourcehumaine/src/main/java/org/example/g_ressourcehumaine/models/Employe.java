package org.example.g_ressourcehumaine.models;

import java.sql.Date;
import java.time.LocalDate;

public class Employe {
    private int id;
    private String nom_complet;
    private String poste;
    private double salaire;
    private Date date_embauche;
    private int departement_id;

    public Employe(int id, String nom_complet, String poste, double salaire, Date date_embauche, int departement_id) {
        this.id = id;
        this.nom_complet = nom_complet;
        this.poste = poste;
        this.salaire = salaire;
        this.date_embauche = date_embauche;
        this.departement_id = departement_id;
    }

    public int getDepartement_id() {
        return departement_id;
    }

    public void setDepartement_id(int departement_id) {
        this.departement_id = departement_id;
    }

    public int getId() {
        return id;
    }

    public String getNom_complet() {
        return nom_complet;
    }

    public String getPoste() {
        return poste;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNom_complet(String nom_complet) {
        this.nom_complet = nom_complet;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }

    public void setDate_embauche(Date date_embauche) {
        this.date_embauche = date_embauche;
    }

    public double getSalaire() {
        return salaire;
    }

    public Date getDate_embauche() {
        return date_embauche;
    }
}
