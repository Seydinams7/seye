package org.example.g_ressourcehumaine.utils;



import org.example.g_ressourcehumaine.models.Utilisateur;

public class SessionManager {
    private static Utilisateur utilisateurConnecte;

    public static void setUtilisateur(Utilisateur user) {
        utilisateurConnecte = user;
    }

    public static Utilisateur getUtilisateur() {
        return utilisateurConnecte;
    }

    public static boolean estAdmin() {
        return utilisateurConnecte != null && utilisateurConnecte.getRole().equals("ADMIN");
    }

    public static boolean estManager() {
        return utilisateurConnecte != null && utilisateurConnecte.getRole().equals("MANAGER");
    }
}
