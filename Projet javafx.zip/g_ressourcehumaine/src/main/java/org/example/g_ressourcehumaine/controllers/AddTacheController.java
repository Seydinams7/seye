package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.utils.DBUtil;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class AddTacheController {
    @FXML
    private TextField txtTitre;
    @FXML
    private TextField txtDescription;
    @FXML
    private DatePicker dateLimite;
    @FXML
    private TextField txtEtat;
    @FXML
    private ComboBox<String> comboEmployee;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnTachehome;

    @FXML
    public void initialize() {

        System.out.println("comboEmployee: " + comboEmployee); // Vérification

        if (comboEmployee == null) {
            System.out.println("Erreur : comboEmployee est null !");
            return;
        }

        // Charger les noms des départements dans la ComboBox
        List<String> employee = DBUtil.getEmployeeNames();
        comboEmployee.getItems().addAll(employee);

    }

    @FXML
    private void handleAddTache() {
        String titre = txtTitre.getText();
        String description = txtDescription.getText();
        LocalDate date = dateLimite.getValue();
        String etat = txtEtat.getText();
        String employeNom = comboEmployee.getValue();

        if (titre.isEmpty() || description.isEmpty() || date == null || etat.isEmpty() || employeNom == null) {
            showAlert("Erreur", "Veuillez remplir tous les champs.", Alert.AlertType.ERROR);
            return;
        }


            try{
            int employe_id = DBUtil.getEmployeeIdByName(employeNom);
            boolean success = DBUtil.addTache(titre, description, Date.valueOf(date), etat, employe_id);

            if (success) {
                showAlert("Succès", "Tache ajouté avec succès.", Alert.AlertType.INFORMATION);
                clearFields();
                navigateTo("manage_taches.fxml",btnAjouter);
            } else {
                showAlert("Erreur", "Erreur lors de l'ajout de la tache.", Alert.AlertType.ERROR);
            }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

    }

    private void clearFields() {
        txtTitre.clear();
        txtDescription.clear();
        dateLimite.setValue(null);
        txtEtat.clear();
        comboEmployee.getSelectionModel().clearSelection();
    }


    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    public void handleTachehome(ActionEvent event) {
        navigateTo("manage_taches.fxml",btnTachehome);
    }
}
