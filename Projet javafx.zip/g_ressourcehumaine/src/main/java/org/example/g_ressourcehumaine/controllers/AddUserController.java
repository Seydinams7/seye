package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.models.Utilisateur;
import org.example.g_ressourcehumaine.utils.DBUtil;
import java.io.IOException;
import java.util.List;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
public class AddUserController {

    @FXML
    private TextField txtnom_utilisateur;

    @FXML
    private PasswordField txtmot_de_passe;
    @FXML
    private TextField txtemail;

    @FXML
    private ComboBox<String> comboRole;

    @FXML
    private Button btnUserhome;

    @FXML
    private Button btnAddUser;

    @FXML
    public void initialize() {

        System.out.println("comboRole: " + comboRole); // Vérification

        if (comboRole == null) {
            System.out.println("Erreur : comboRole est null !");
            return;
        }

        // Charger les noms des départements dans la ComboBox
        List<String> roles = DBUtil.getRoleNames();
        comboRole.getItems().addAll("ADMIN", "MANAGER");

    }


    @FXML
    private void handleAddUser() {
        String nom_utilisateur = txtnom_utilisateur.getText();
        String mot_de_passe = txtmot_de_passe.getText();
        String email = txtemail.getText();
        String role = comboRole.getValue();

        if (nom_utilisateur.isEmpty() || mot_de_passe.isEmpty() || email.isEmpty() || role == null) {
            showAlert("Erreur", "Veuillez remplir tous les champs.", Alert.AlertType.ERROR);
            return;
        }
        // Hacher le mot de passe avant de l'envoyer à la base de données
        String hashedPassword = hashPassword(mot_de_passe);

        if (hashedPassword == null) {
            showAlert("Erreur", "Échec du hachage du mot de passe.", AlertType.ERROR);
            return;
        }


            boolean success = DBUtil.addUser(nom_utilisateur, hashedPassword, email, role);

            if (success) {
                showAlert("Succès", "Utilisateur ajouté avec succès.", Alert.AlertType.INFORMATION);
                clearFields();
                navigateTo("manage_users.fxml",btnAddUser);
            } else {
                showAlert("Erreur", "Erreur lors de l'ajout de l'utilisateur.", Alert.AlertType.ERROR);
            }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());

            // Convertir les bytes en format hexadécimal
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b)); // Convertir chaque byte en 2 caractères hex
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }



    private void clearFields() {
        txtnom_utilisateur.clear();
        txtmot_de_passe.clear();
        txtemail.clear();
        comboRole.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    public void handleUserhome(ActionEvent event) {
        navigateTo("manage_users.fxml",btnUserhome);
    }
}
