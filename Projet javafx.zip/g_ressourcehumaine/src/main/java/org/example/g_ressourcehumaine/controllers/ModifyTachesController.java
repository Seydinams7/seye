package org.example.g_ressourcehumaine.controllers;



import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.models.Tache;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ModifyTachesController {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion_ressource_humaine";
    private static final String DB_USER = "root"; // Assure-toi que c'est le bon nom d'utilisateur
    private static final String DB_PASSWORD = ""; // Assure-toi que c'est le bon mot de passe

    @FXML private TextField titreField;
    @FXML private TextField descriptionField;
    @FXML
    private TextField dateField;

    @FXML
    private TextField etatField;

    @FXML
    private Button btnAnnuler;

    private Tache tache;

    public void setTache(Tache tache) {
        this.tache = tache;
        // Remplir les champs avec les informations de l'employé
        if (tache != null) {
            titreField.setText(tache.getTitre());
            descriptionField.setText(tache.getDescription());
            dateField.setText(String.valueOf(tache.getDateLimite()));
            etatField.setText(String.valueOf(tache.getEtat()));
        }
    }

    @FXML
    public void handleSaveChanges() {
        try {
            // Récupérer les nouvelles valeurs des champs
            String newTitre = titreField.getText();
            String newDescription = descriptionField.getText();
            String newDate = dateField.getText(); // Vous pouvez utiliser un format de date spécifique si nécessaire
            String newEtat = etatField.getText();
            // Mettre à jour l'employé avec les nouvelles informations
            tache.setTitre(newTitre);
            tache.setDescription(newDescription);
            // Si nécessaire, parsez la date pour mettre à jour la date d'embauche dans l'employé
            java.util.Date utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(newDate);
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
            tache.setDateLimite(sqlDate);
            tache.setEtat(newEtat);

            // Ici, vous devez mettre à jour la base de données si nécessaire
            // Par exemple, appelez un service pour sauvegarder les données en base
            // Mettre à jour l'employé dans la base de données
            updateTacheInDatabase(tache);


            // Confirmer à l'utilisateur que l'employé a bien été modifié
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Les informations de la tache ont été mises à jour.");
            alert.showAndWait();


            // Fermer la fenêtre après l'enregistrement
            Stage stage = (Stage) titreField.getScene().getWindow();
            stage.close();

        } catch (ParseException e) {
            // Gérer l'exception si la date d'embauche n'est pas valide
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur de format de date");
            alert.setContentText("La date d'embauche doit être au format 'yyyy-MM-dd'.");
            alert.showAndWait();
        }
    }

    private void updateTacheInDatabase(Tache tache) {
        // Code pour mettre à jour l'employé dans la base de données via JDBC
        String sql = "UPDATE taches SET titre = ?, description = ?, date_limite = ?, etat = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tache.getTitre());
            stmt.setString(2, tache.getDescription());
            stmt.setDate(3, new java.sql.Date(tache.getDateLimite().getTime()));
            stmt.setString(4, tache.getEtat());
            stmt.setInt(5, tache.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Navigation vers une autre vue
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleCancel(ActionEvent event){
        navigateTo("admin.fxml", btnAnnuler);

    }
}

