package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import java.sql.*;

public class AddDepartmentController {

    @FXML private TextField nomField;  // Champ de texte pour le nom du département

    @FXML private ComboBox<String> comboManagers;  // ComboBox pour sélectionner un manager
    @FXML private Button btnSave;
    @FXML private Button btnCancel;
    @FXML private Button btnDepartmenthome;

    private ObservableList<String> managerList = FXCollections.observableArrayList(); // Liste des managers

    @FXML
    public void initialize() {
        chargerManagers(); // Charger les managers dans le ComboBox
    }

    // Charger les managers depuis la base de données
    private void chargerManagers() {
        managerList.clear();
        String query = "SELECT id, nom_utilisateur FROM utilisateurs WHERE role = 'MANAGER'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nom = rs.getString("nom_utilisateur");
                managerList.add(id + " - " + nom);  // Stocke sous forme "id - nom"
            }

            comboManagers.setItems(managerList);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger les managers.", Alert.AlertType.ERROR);
        }
    }

    // Enregistrer un nouveau département avec un responsable
    @FXML
    private void handleSave() {
        String selectedManager = comboManagers.getValue();
        String nom = nomField.getText();

        // Vérification si le champ est vide
        if (nom == null || nom.trim().isEmpty()) {
            showAlert("Erreur", "Le nom du département ne peut pas être vide.", Alert.AlertType.ERROR);
            return;
        }

        if (selectedManager == null) {
            showAlert("Erreur", "Veuillez sélectionner un manager.", Alert.AlertType.ERROR);
            return;
        }

        int managerId = Integer.parseInt(selectedManager.split(" - ")[0]); // Extraire l'ID du manager

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO departements (nom, responsable_id) VALUES (?, ?)");
            stmt.setString(1, nom);
            stmt.setInt(2, managerId);
            stmt.executeUpdate();

            showAlert("Succès", "Département ajouté avec succès.", Alert.AlertType.INFORMATION);
            navigateTo("manage_departments.fxml", btnSave);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Une erreur est survenue lors de l'ajout du département.", Alert.AlertType.ERROR);
        }
    }

    // Annuler et fermer la fenêtre
    @FXML
    private void handleCancel() {
        btnCancel.getScene().getWindow().hide();
    }

    // Navigation entre les pages
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du chargement de la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    public void handleDepartmenthome(ActionEvent event) {
        navigateTo("manage_departments.fxml", btnDepartmenthome);
    }

    // Méthode pour afficher des alertes
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
