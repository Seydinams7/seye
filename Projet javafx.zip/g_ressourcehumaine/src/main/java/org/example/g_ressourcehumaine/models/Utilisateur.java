package org.example.g_ressourcehumaine.models;



public class Utilisateur {
    private int id;
    private String nomUtilisateur;
    private String mot_de_passe;
    private String email;
    private String role;

    public Utilisateur(int id, String nomUtilisateur, String mot_de_passe, String email, String role) {
        this.id = id;
        this.nomUtilisateur = nomUtilisateur;
        this.mot_de_passe = mot_de_passe;
        this.email = email;
        this.role = role;
    }

    public Utilisateur() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getMot_de_passe() {
        return mot_de_passe;
    }

    public void setMot_de_passe(String mot_de_passe) {
        this.mot_de_passe = mot_de_passe;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
