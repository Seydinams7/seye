package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.models.Utilisateur;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ModifyUserController {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion_ressource_humaine";
    private static final String DB_USER = "root"; // Assure-toi que c'est le bon nom d'utilisateur
    private static final String DB_PASSWORD = ""; // Assure-toi que c'est le bon mot de passe

    @FXML
    private TextField nameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField emailField;
    @FXML
    private TextField roleField;

    @FXML
    private Button btnAnnuler;

    private Utilisateur utilisateur;

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
        // Remplir les champs avec les informations de l'employé
        if (utilisateur != null) {
            nameField.setText(utilisateur.getNomUtilisateur());
            passwordField.setText(utilisateur.getMot_de_passe());
            emailField.setText(String.valueOf(utilisateur.getEmail()));
            roleField.setText((utilisateur.getRole()));
        }
    }

    @FXML
    public void handleSaveChanges() {
            // Récupérer les nouvelles valeurs des champs
            String newName = nameField.getText();
            String newPassword = passwordField.getText();
            String newEmail = emailField.getText(); // Assurez-vous que le salaire est bien un nombre
            String newRole = roleField.getText(); // Vous pouvez utiliser un format de date spécifique si nécessaire

            // Mettre à jour l'employé avec les nouvelles informations
            utilisateur.setNomUtilisateur(newName);
            utilisateur.setMot_de_passe(hashPassword(newPassword));
            utilisateur.setEmail(newEmail);
            utilisateur.setRole(newRole);
            // Si nécessaire, parsez la date pour mettre à jour la date d'embauche dans l'employé

            // Ici, vous devez mettre à jour la base de données si nécessaire
            // Par exemple, appelez un service pour sauvegarder les données en base
            // Mettre à jour l'employé dans la base de données
            updateUserInDatabase(utilisateur);


            // Confirmer à l'utilisateur que l'employé a bien été modifié
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Les informations de l'utilisateur ont été mises à jour.");
            alert.showAndWait();


            // Fermer la fenêtre après l'enregistrement
            Stage stage = (Stage) nameField.getScene().getWindow();
            stage.close();


    }

    private void updateUserInDatabase(Utilisateur utilisateur) {
        // Code pour mettre à jour l'employé dans la base de données via JDBC
        String sql = "UPDATE utilisateurs SET nom_utilisateur = ?, mot_de_passe = ?, email = ?, role = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, utilisateur.getNomUtilisateur());
            stmt.setString(2, utilisateur.getMot_de_passe());
            stmt.setString(3, utilisateur.getEmail());
            stmt.setString(4, utilisateur.getRole());
            stmt.setInt(5, utilisateur.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Navigation vers une autre vue
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    @FXML
    public void handleCancel(ActionEvent event){
        navigateTo("admin.fxml", btnAnnuler);

    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());

            // Convertir les bytes en format hexadécimal
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b)); // Convertir chaque byte en 2 caractères hex
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
