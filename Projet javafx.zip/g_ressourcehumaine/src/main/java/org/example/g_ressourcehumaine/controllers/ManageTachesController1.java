package org.example.g_ressourcehumaine.controllers;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.Tache;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.g_ressourcehumaine.models.Tache;
import org.example.g_ressourcehumaine.database.DatabaseConnection;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.scene.control.Alert;

public class ManageTachesController1 implements Initializable {

    @FXML private TableView<Tache> tableTaches;
    @FXML private TableColumn<Tache, Integer> colId;
    @FXML private TableColumn<Tache, String> colTitre;
    @FXML private TableColumn<Tache, String> colDescription;
    @FXML private TableColumn<Tache, String> colDateLimite;
    @FXML private TableColumn<Tache, String> colEtat;
    @FXML private Button btnAjouterTache;
    @FXML private Button btnModifierTache;
    @FXML private Button btnSupprimerTache;

    private int managerId;
    private int departmentId;

    // 🔹 Initialisation
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDateLimite.setCellValueFactory(new PropertyValueFactory<>("dateLimite"));
        colEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));
    }

    // 🔹 Récupérer les informations du manager depuis `ManagerController`
    public void setManagerData(int managerId, int departmentId) {
        this.managerId = managerId;
        this.departmentId = departmentId;
        loadTasks();
    }

    // 🔹 Charger uniquement les tâches des employés du département du manager
    private void loadTasks() {
        tableTaches.getItems().clear();
        String query = "SELECT t.* FROM taches t JOIN employes e ON t.employe_id = e.id WHERE e.departement_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, departmentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Tache tache = new Tache(
                        rs.getInt("id"),
                        rs.getString("titre"),
                        rs.getString("description"),
                        rs.getDate("date_limite"),
                        rs.getString("etat"),
                        rs.getInt("employe_id")
                );
                tableTaches.getItems().add(tache);
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger les tâches.", Alert.AlertType.ERROR);
        }
    }

    // 🔹 Afficher une alerte
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

