package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.Employe;
import org.example.g_ressourcehumaine.models.Utilisateur;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UserController implements Initializable {

    @FXML
    private TableView<Utilisateur> tableViewUsers;

    @FXML
    private TableColumn<Utilisateur, Integer> columnId;
    @FXML
    private TableColumn<Utilisateur, String> columnUsername;

    @FXML
    private TableColumn<Utilisateur, String> columnPassword;
    @FXML
    private TableColumn<Utilisateur, String> columnEmail;
    @FXML
    private TableColumn<Utilisateur, String> columnRole;

    @FXML
    private Button btnAddUser;

    @FXML
    private Button btnModify;

    @FXML
    private Button btnAdminhome;
    private ObservableList<Utilisateur> userList;

    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialiser les colonnes du tableau
        userList = FXCollections.observableArrayList();


        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnUsername.setCellValueFactory(new PropertyValueFactory<>("nomUtilisateur"));
        columnPassword.setCellValueFactory(new PropertyValueFactory<>("mot_de_passe"));
        columnEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        columnRole.setCellValueFactory(new PropertyValueFactory<>("role"));

        // Ajouter la liste d'utilisateurs au tableau
        loadUser();
    }

    private void loadUser() {
        userList.clear();
        String query = "SELECT * FROM utilisateurs";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Utilisateur utilisateur = new Utilisateur(
                        rs.getInt("id"),
                        rs.getString("nom_utilisateur"),
                        rs.getString("mot_de_passe"),
                        rs.getString("email"),
                        rs.getString("role")
                );
                userList.add(utilisateur);
            }
            tableViewUsers.setItems(userList);

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger les utilisateurs.", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du chargement de la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }
    public void handleAddUser(ActionEvent event) {
        navigateTo("AddUser.fxml",btnAddUser);
    }

    public void handleAdminhome(ActionEvent event) {
        navigateTo("admin.fxml",btnAdminhome);
    }

    public void handleDeleteUser(ActionEvent event) {
        Utilisateur selectedUser = tableViewUsers.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert("Attention", "Veuillez sélectionner un utilisateur à supprimer.", Alert.AlertType.WARNING);
            return;
        }

        String query = "DELETE FROM utilisateurs WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedUser.getId());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                showAlert("Succès", "Utilisateur supprimé avec succès.", Alert.AlertType.INFORMATION);
                loadUser(); // Rafraîchir la table
            } else {
                showAlert("Erreur", "La suppression a échoué.", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de supprimer l'utilisateur.", Alert.AlertType.ERROR);
        }
    }

    public void handleModifyUser(ActionEvent event) {
        Utilisateur selectedUser = tableViewUsers.getSelectionModel().getSelectedItem();

        // Vérifier si un employé a été sélectionné
        if (selectedUser == null) {
            // Afficher un message d'erreur si aucun employé n'est sélectionné
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucun utilisateur sélectionné");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez sélectionner un utilisateur à modifier.");
            alert.showAndWait();
            return;
        }

        // Créer un formulaire de modification (nouvelle fenêtre ou dialog)
        try {
            // Charger le fichier FXML du formulaire de modification
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/modifyUserForm.fxml"));
            Parent root = loader.load();

            // Passer l'employé sélectionné au contrôleur de la fenêtre de modification
            ModifyUserController modifyController = loader.getController();
            modifyController.setUtilisateur(selectedUser); // Passer l'employé à modifier

            // Afficher la nouvelle fenêtre dans un Stage
            Stage stage = new Stage();
            stage.setTitle("Modifier un Utilisateur");
            stage.setScene(new Scene(root));
            stage.showAndWait(); // Attendre que l'utilisateur ferme la fenêtre
        } catch (IOException e) {
            e.printStackTrace();
            // Gérer les erreurs de chargement de la fenêtre de modification
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur lors de l'ouverture du formulaire de modification");
            alert.setContentText("Impossible de charger le formulaire de modification.");
            alert.showAndWait();

        }
    }

    public void handleRefreshUser(ActionEvent event) {
        loadUser();
    }
}
