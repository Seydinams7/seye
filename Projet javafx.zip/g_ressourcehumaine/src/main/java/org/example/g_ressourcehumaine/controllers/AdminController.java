package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class AdminController {

    @FXML
    private Button btnManageEmployees;
    @FXML
    private Button btnManageDepartments;
    @FXML
    private Button btnManageUsers;
    @FXML
    private Button btnManageTaches;
    @FXML
    private Button btnLogout;

    @FXML
    public void handleManageEmployees() {
        System.out.println("Gestion des employés");
        navigateTo("manage_employees.fxml", btnManageEmployees);
    }

    @FXML
    public void handleManageDepartments() {
        System.out.println("Gestion des départements");
        navigateTo("manage_departments.fxml", btnManageDepartments);
    }

    @FXML
    public void handleManageUsers() {
        System.out.println("Gestion des utilisateurs");
        navigateTo("manage_users.fxml", btnManageUsers);
    }

    @FXML
    public void handleLogout() {
        System.out.println("Déconnexion");
        navigateTo("public_view.fxml", btnLogout);
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du chargement de la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }


    public void handleManageTaches(ActionEvent event) {
        System.out.println("Gestion des Taches");
        navigateTo("manage_taches.fxml", btnManageTaches);

    }
}
