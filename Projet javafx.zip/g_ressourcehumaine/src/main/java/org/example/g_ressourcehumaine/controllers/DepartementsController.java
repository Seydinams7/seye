package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import org.example.g_ressourcehumaine.database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import org.example.g_ressourcehumaine.models.Departement;
import org.example.g_ressourcehumaine.models.Employe;


import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class DepartementsController implements Initializable {

    @FXML private TableView<Departement> tableDepartements;  // TableView pour afficher les départements

    @FXML private TableColumn<Departement, Integer> columnId;  // Colonne pour l'ID

    @FXML private TableColumn<Departement, String> columnNom;  // Colonne pour le nom du département

    @FXML private TableColumn<Departement, Integer> columnResponsableid;
    @FXML private TextField nomField;

    @FXML
    private Button btnAdminhome;
    @FXML
    private Button btnModify;


    @FXML
    private Button btnAddDepartment;  // Ajoutez cette ligne pour lier le bouton


    // Nous n'utilisons plus de listes ici, mais directement un tableau

    private ObservableList<Departement> departmentsList = FXCollections.observableArrayList();

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        columnResponsableid.setCellValueFactory(new PropertyValueFactory<>("responsable_id"));

        chargerDepartements();
    }

    private void chargerDepartements() {
        System.out.println("Chargement des départements...");

        departmentsList.clear();
        String query = "SELECT * FROM departements";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Departement departement = new Departement(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getInt("responsable_id")

                );
                departmentsList.add(departement);

            }
            System.out.println("TableView instance: " + tableDepartements);

            tableDepartements.setItems(departmentsList);
            System.out.println("Départements récupérés : " + departmentsList.size());


        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger les depatements.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void ajouterDepartement() {
        String nom = nomField.getText();

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO departements (nom) VALUES (?)");
            stmt.setString(1, nom);
            stmt.executeUpdate();
            chargerDepartements();  // Recharger les départements après ajout
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void supprimerDepartement() {
        Departement selectedDepartement = tableDepartements.getSelectionModel().getSelectedItem();
        if (selectedDepartement == null) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM departements WHERE id = ?");
            stmt.setInt(1, selectedDepartement.getId());
            stmt.executeUpdate();
            chargerDepartements();  // Recharger les départements après suppression
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddDepartment(ActionEvent event) {
        // Créer une fenêtre d'ajout de département
        System.out.println("Déconnexion");
        navigateTo("AddDepartment.fxml", btnAddDepartment);
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors du chargement de la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    public void handleAdminhome(ActionEvent event){
        navigateTo("admin.fxml",btnAdminhome);
    }

    public void handleDeleteDepartment(ActionEvent event) {
        Departement selectedDepartment = tableDepartements.getSelectionModel().getSelectedItem();
        if (selectedDepartment == null) {
            showAlert("Attention", "Veuillez sélectionner un departement à supprimer.", Alert.AlertType.WARNING);
            return;
        }

        String query = "DELETE FROM departements WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedDepartment.getId());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                showAlert("Succès", "Departement supprimé avec succès.", Alert.AlertType.INFORMATION);
                chargerDepartements(); // Rafraîchir la table
            } else {
                showAlert("Erreur", "La suppression a échoué.", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de supprimer le departements.", Alert.AlertType.ERROR);
        }
    }

    public void handleModifyDepartment(ActionEvent event) {
        Departement selectedDepartment = tableDepartements.getSelectionModel().getSelectedItem();

        // Vérifier si un employé a été sélectionné
        if (selectedDepartment == null) {
            // Afficher un message d'erreur si aucun employé n'est sélectionné
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucun Departements sélectionné");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez sélectionner un departement à modifier.");
            alert.showAndWait();
            return;
        }

        // Créer un formulaire de modification (nouvelle fenêtre ou dialog)
        try {
            // Charger le fichier FXML du formulaire de modification
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/modifyDepartmentForm.fxml"));
            Parent root = loader.load();

            // Passer l'employé sélectionné au contrôleur de la fenêtre de modification
            ModifyDepartmentController modifyController = loader.getController();
            modifyController.setDepartement(selectedDepartment); // Passer l'employé à modifier

            // Afficher la nouvelle fenêtre dans un Stage
            Stage stage = new Stage();
            stage.setTitle("Modifier un departement");
            stage.setScene(new Scene(root));
            stage.showAndWait(); // Attendre que l'utilisateur ferme la fenêtre
        } catch (IOException e) {
            e.printStackTrace();
            // Gérer les erreurs de chargement de la fenêtre de modification
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur lors de l'ouverture du formulaire de modification");
            alert.setContentText("Impossible de charger le formulaire de modification.");
            alert.showAndWait();

        }
    }

    public void handleRefreshDepartment(ActionEvent event) {
        chargerDepartements();
    }
}
