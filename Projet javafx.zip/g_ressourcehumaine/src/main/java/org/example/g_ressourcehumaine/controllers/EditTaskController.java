package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.models.Tache;
import java.sql.*;
import java.time.LocalDate;
import java.time.ZoneId;

public class EditTaskController {

    @FXML private TextField titleField;
    @FXML private TextField descriptionField;
    @FXML private DatePicker deadlinePicker;
    @FXML private TextField etatComboBox;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion_ressource_humaine";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private Tache taskToEdit;

    // Méthode pour définir les données de la tâche à modifier
    public void setTaskData(Tache tache) {
        this.taskToEdit = tache;

        // Remplir les champs avec les données de la tâche
        titleField.setText(tache.getTitre());
        descriptionField.setText(tache.getDescription());

        // Convertir java.util.Date en java.time.LocalDate pour DatePicker


        etatComboBox.setText(tache.getEtat());
    }

    @FXML
    public void handleSave(ActionEvent event) {
        // Vérifier que tous les champs sont remplis
        if (titleField.getText().isEmpty() || descriptionField.getText().isEmpty() || deadlinePicker.getValue() == null) {
            showAlert("Erreur", "Tous les champs doivent être remplis.", Alert.AlertType.ERROR);
            return;
        }

        // Mettre à jour la tâche
        taskToEdit.setTitre(titleField.getText());
        taskToEdit.setDescription(descriptionField.getText());

        // Convertir LocalDate en java.util.Date
        LocalDate localDate = deadlinePicker.getValue();
        java.util.Date dateLimite = java.util.Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        taskToEdit.setDateLimite(dateLimite);

        taskToEdit.setEtat(etatComboBox.getText());

        // Sauvegarder les modifications dans la base de données
        updateTaskInDatabase(taskToEdit);

        // Fermer la fenêtre d'édition
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }

    // Méthode pour sauvegarder les modifications dans la base de données
    private void updateTaskInDatabase(Tache tache) {
        String updateQuery = "UPDATE taches SET titre = ?, description = ?, date_limite = ?, etat = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
            stmt.setString(1, tache.getTitre());
            stmt.setString(2, tache.getDescription());

            // Convertir java.util.Date en java.sql.Date
            java.sql.Date sqlDate = new java.sql.Date(tache.getDateLimite().getTime());
            stmt.setDate(3, sqlDate);

            stmt.setString(4, tache.getEtat());
            stmt.setInt(5, tache.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la sauvegarde des modifications.", Alert.AlertType.ERROR);
        }
    }

    // Afficher une alerte
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    public void handleCancel(ActionEvent event) {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }

}
