package org.example.g_ressourcehumaine.models;

public class Departement {
    private int id;
    private String nom;

    private int responsable_id;

    public Departement(int id, String nom, int responsable_id) {
        this.id = id;
        this.nom = nom;
        this.responsable_id = responsable_id;
    }

    public Departement() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getResponsable_id() {
        return responsable_id;
    }

    public void setResponsable_id(int responsable_id) {
        this.responsable_id = responsable_id;
    }
}
