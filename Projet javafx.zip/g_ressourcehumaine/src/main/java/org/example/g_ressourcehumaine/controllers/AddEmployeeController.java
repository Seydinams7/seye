package org.example.g_ressourcehumaine.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.utils.DBUtil;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class AddEmployeeController {
    @FXML
    private TextField txtNomComplet;
    @FXML
    private TextField txtPoste;
    @FXML
    private DatePicker dateEmbauche;
    @FXML
    private TextField txtSalaire;
    @FXML
    private ComboBox<String> comboDepartement;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnEmployehome;

    @FXML
    public void initialize() {

        System.out.println("comboDepartement: " + comboDepartement); // Vérification

        if (comboDepartement == null) {
            System.out.println("Erreur : comboDepartement est null !");
            return;
        }

        // Charger les noms des départements dans la ComboBox
        List<String> departements = DBUtil.getDepartementNames();
        comboDepartement.getItems().addAll(departements);

    }

    @FXML
    private void handleAddEmployee() {
        String nomComplet = txtNomComplet.getText();
        String poste = txtPoste.getText();
        LocalDate date = dateEmbauche.getValue();
        String salaireStr = txtSalaire.getText();
        String departementNom = comboDepartement.getValue();

        if (nomComplet.isEmpty() || poste.isEmpty() || date == null || salaireStr.isEmpty() || departementNom == null) {
            showAlert("Erreur", "Veuillez remplir tous les champs.", Alert.AlertType.ERROR);
            return;
        }

        try {
            double salaire = Double.parseDouble(salaireStr);
            int departementId = DBUtil.getDepartementIdByName(departementNom);
            boolean success = DBUtil.addEmployee(nomComplet, poste, Date.valueOf(date), salaire, departementId);

            if (success) {
                showAlert("Succès", "Employé ajouté avec succès.", Alert.AlertType.INFORMATION);
                clearFields();
                navigateTo("manage_employees.fxml",btnAjouter);
            } else {
                showAlert("Erreur", "Erreur lors de l'ajout de l'employé.", Alert.AlertType.ERROR);
            }
        } catch (NumberFormatException e) {
            showAlert("Erreur", "Le salaire doit être un nombre.", Alert.AlertType.ERROR);
        }
    }

    private void clearFields() {
        txtNomComplet.clear();
        txtPoste.clear();
        dateEmbauche.setValue(null);
        txtSalaire.clear();
        comboDepartement.getSelectionModel().clearSelection();
    }


    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    public void handleEmployehome(ActionEvent event) {
        navigateTo("manage_employees.fxml",btnEmployehome);
    }
}
