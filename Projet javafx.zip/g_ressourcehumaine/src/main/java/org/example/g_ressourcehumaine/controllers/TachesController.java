package org.example.g_ressourcehumaine.controllers;


import org.example.g_ressourcehumaine.database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.g_ressourcehumaine.models.Tache;
import java.sql.*;

public class TachesController {
    @FXML private TableView<Tache> tableTaches;
    @FXML private TextField titreField, descriptionField;
    @FXML private DatePicker dateLimitePicker;
    @FXML private ComboBox<String> etatCombo;

    private ObservableList<Tache> tachesList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        chargerTaches();
    }

    private void chargerTaches() {
        tachesList.clear();
        try (Connection conn = DatabaseConnection.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM taches");
            while (rs.next()) {
                tachesList.add(new Tache(rs.getInt("id"), rs.getString("titre"),
                        rs.getString("description"), rs.getString("etat"), rs.getInt("employe_id")));
            }
            tableTaches.setItems(tachesList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void ajouterTache() {
        String titre = titreField.getText();
        String description = descriptionField.getText();
        String etat = etatCombo.getValue();

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO taches (titre, description, etat) VALUES (?, ?, ?)");
            stmt.setString(1, titre);
            stmt.setString(2, description);
            stmt.setString(3, etat);
            stmt.executeUpdate();
            chargerTaches();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void supprimerTache() {
        Tache selectedTache = tableTaches.getSelectionModel().getSelectedItem();
        if (selectedTache == null) return;

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM taches WHERE id = ?");
            stmt.setInt(1, selectedTache.getId());
            stmt.executeUpdate();
            chargerTaches();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
