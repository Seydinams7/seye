package org.example.g_ressourcehumaine.controllers;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.example.g_ressourcehumaine.database.DatabaseConnection;
import org.example.g_ressourcehumaine.models.Tache;
import org.example.g_ressourcehumaine.controllers.ModifyTachesController;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;



public class ManageTachesController implements Initializable {

    @FXML
    private TextField nameField;
    @FXML
    private TextField titreField;
    @FXML
    private TextField descriptionField;
    @FXML
    private TextField dateField;

    @FXML
    private TextField etatField;

    private Tache tache;

    @FXML
    private TableView<Tache> tableViewTaches;
    @FXML
    private TableColumn<Tache, Integer> columnId;
    @FXML
    private TableColumn<Tache, String> columnTitre;
    @FXML
    private TableColumn<Tache, String> columnDescription;
    @FXML
    private TableColumn<Tache, Date> columnDate;
    @FXML
    private TableColumn<Tache, String> columnEtat;
    @FXML
    private TableColumn<Tache, String> columnEmployeid;
    @FXML
    private Button btnAddTache;
    @FXML
    private Button btnAdminhome;
    @FXML
    private Button btnModify;
    @FXML
    private Button btnDeleteTache;
    @FXML
    private Button btnRefresh;

    private ObservableList<Tache> tachesList = FXCollections.observableArrayList();




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialisation des colonnes de la TableView
        columnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
        columnDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        columnDate.setCellValueFactory(new PropertyValueFactory<>("dateLimite"));
        columnEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));
        columnEmployeid.setCellValueFactory(new PropertyValueFactory<>("employe_id"));

        // Charger les employés
        loadTaches();
    }

    // Cette méthode permet de recevoir l'employé sélectionné

    // Méthode pour charger les employés depuis la base de données
    private void loadTaches() {
        tachesList.clear();
        String query = "SELECT * FROM taches";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Tache tache = new Tache(
                        rs.getInt("id"),
                        rs.getString("titre"),
                        rs.getString("description"),
                        rs.getDate("date_limite"),
                        rs.getString("etat"),
                        rs.getInt("employe_id")
                );
                tachesList.add(tache);
            }
            tableViewTaches.setItems(tachesList);

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger les taches.", Alert.AlertType.ERROR);
        }
    }

    // Méthode pour afficher une alerte
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Navigation vers une autre vue
    private void navigateTo(String fxmlFile, Button sourceButton) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/" + fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) sourceButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de charger la page : " + fxmlFile, Alert.AlertType.ERROR);
        }
    }

    // Ajouter un employé
    @FXML

    public void handleAdminhome(ActionEvent event){
        navigateTo("admin.fxml",btnAdminhome);
    }
    @FXML
    public void handleAddTache(ActionEvent event) {
        navigateTo("AddTache.fxml", btnAddTache);
    }

    // Supprimer un employé sélectionné
    @FXML
    public void handleDeleteTache(ActionEvent event) {
        Tache selectedTache = tableViewTaches.getSelectionModel().getSelectedItem();
        if (selectedTache == null) {
            showAlert("Attention", "Veuillez sélectionner une tache à supprimer.", Alert.AlertType.WARNING);
            return;
        }

        String query = "DELETE FROM taches WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedTache.getId());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                showAlert("Succès", "Tache supprimé avec succès.", Alert.AlertType.INFORMATION);
                loadTaches(); // Rafraîchir la table
            } else {
                showAlert("Erreur", "La suppression a échoué.", Alert.AlertType.ERROR);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Impossible de supprimer la tache.", Alert.AlertType.ERROR);
        }
    }

    // Rafraîchir la liste des employés
    @FXML
    public void handleModifyTache(ActionEvent event) {
        Tache selectedTache = tableViewTaches.getSelectionModel().getSelectedItem();

        // Vérifier si un employé a été sélectionné
        if (selectedTache == null) {
            // Afficher un message d'erreur si aucun employé n'est sélectionné
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucune tache sélectionné");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez sélectionner une tache à modifier.");
            alert.showAndWait();
            return;
        }

        // Créer un formulaire de modification (nouvelle fenêtre ou dialog)
        try {
            // Charger le fichier FXML du formulaire de modification
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/g_ressourcehumaine/views/modifyTacheForm.fxml"));
            Parent root = loader.load();

            // Passer l'employé sélectionné au contrôleur de la fenêtre de modification
            ModifyTachesController modifyController = loader.getController();
            modifyController.
                    setTache(selectedTache); // Passer l'employé à modifier

            // Afficher la nouvelle fenêtre dans un Stage
            Stage stage = new Stage();
            stage.setTitle("Modifier une tache");
            stage.setScene(new Scene(root));
            stage.showAndWait(); // Attendre que l'utilisateur ferme la fenêtre
        } catch (IOException e) {
            e.printStackTrace();
            // Gérer les erreurs de chargement de la fenêtre de modification
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur lors de l'ouverture du formulaire de modification");
            alert.setContentText("Impossible de charger le formulaire de modification.");
            alert.showAndWait();

        }
    }


    public void handleRefreshTache(ActionEvent event) {
        loadTaches();

    }
}

