package org.example.g_ressourcehumaine.models;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class EmployeeTask {
    private final StringProperty nom;
    private final StringProperty poste;
    private final StringProperty tache;
    private final StringProperty etat;

    public EmployeeTask(String nom, String poste, String tache, String etat) {
        this.nom = new SimpleStringProperty(nom);
        this.poste = new SimpleStringProperty(poste);
        this.tache = new SimpleStringProperty(tache);
        this.etat = new SimpleStringProperty(etat);
    }

    public String getNom() { return nom.get(); }
    public String getPoste() { return poste.get(); }
    public String getTache() { return tache.get(); }
    public String getEtat() { return etat.get(); }

    public StringProperty nomProperty() { return nom; }
    public StringProperty posteProperty() { return poste; }
    public StringProperty tacheProperty() { return tache; }
    public StringProperty etatProperty() { return etat; }
}
